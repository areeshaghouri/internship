const display = document.getElementById("display");
let currentInput = "";
let operator = "";
let firstValue = null;

document.querySelectorAll("button").forEach((button) => {
    button.addEventListener("click", (e) => {
        const buttonValue = e.target.innerText;

        if (buttonValue >= "0" && buttonValue <= "9") {
            currentInput += buttonValue;
        } else if (buttonValue === ".") {
            if (!currentInput.includes(".")) {
                currentInput += buttonValue;
            }
        } else if (buttonValue === "C") {
            currentInput = "";
            firstValue = null;
            operator = "";
        } else if (["+", "-", "*", "/"].includes(buttonValue)) {
            if (currentInput !== "") {
                if (firstValue === null) {
                    firstValue = parseFloat(currentInput);
                } else {
                    firstValue = calculate(firstValue, parseFloat(currentInput), operator);
                }
                operator = buttonValue;
                currentInput = "";
            }
        } else if (buttonValue === "=") {
            if (currentInput !== "" && firstValue !== null) {
                firstValue = calculate(firstValue, parseFloat(currentInput), operator);
                operator = "";
                currentInput = firstValue.toString();
            }
        }

        display.value = currentInput;
    });
});

function calculate(a, b, operator) {
    switch (operator) {
        case "+":
            return a + b;
        case "-":
            return a - b;
        case "*":
            return a * b;
        case "/":
            return a / b;
        default:
            return b;
    }
}